# Nice Studio para Android (projeto inicial)

Este é um projeto Android Studio que abre o site do Nice Studio dentro de um WebView e solicita permissão de microfone quando a página pede captura de áudio.

## Requisitos
- Android Studio atualizado
- Android SDK 35 instalado pelo SDK Manager
- Conexão com a internet na primeira compilação para baixar dependências

## Como gerar o APK
1. Extraia o ZIP.
2. Abra a pasta `NiceStudioAndroid` no Android Studio.
3. Aguarde a sincronização do Gradle e aceite instalar os componentes do SDK solicitados.
4. Para testar, conecte o celular com depuração USB habilitada ou use um emulador.
5. Para gerar um APK de teste, selecione **Build > Build APK(s)**.
6. O APK de depuração costuma ficar em `app/build/outputs/apk/debug/app-debug.apk`.

## Importante
- Este projeto é uma versão WebView: o site continua hospedado online e o aplicativo precisa de internet.
- A permissão do microfone é encaminhada ao site para captura de áudio.
- Recursos como seleção de arquivos, exportação/compartilhamento de gravações, notificações e funcionamento offline podem exigir implementação adicional dependendo de como o site foi desenvolvido.
- O endereço fornecido é um domínio de preview. Antes de distribuir o aplicativo, confirme que o site terá um endereço permanente.
- Teste gravação, pausa, retomada, exportação e gravações longas em um aparelho real antes de usar em produção.
